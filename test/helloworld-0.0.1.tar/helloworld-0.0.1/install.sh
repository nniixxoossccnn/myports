#!/bin/sh


# 如果变量未定义则退出并返回非0
set -u 

# 安装测试用例
if [ -f ./a.out ]
then
	mkdir -p ${DESTDIR}/bin || exit 1
	mkdir -p ${DESTDIR}/sbin || exit 1
	mkdir -p ${DESTDIR}/lib || exit 1
	mkdir -p ${DESTDIR}/${PREFIX}/bin || exit 1
	mkdir -p ${DESTDIR}/${PREFIX}/lib || exit 1
	mkdir -p ${DESTDIR}/${PREFIX}/libexec || exit 1
	mkdir -p ${DESTDIR}/${PREFIX}/sbin || exit 1

	cp -v a.out ${DESTDIR}/bin/ || exit 1
	cp -v a.out ${DESTDIR}/sbin/ || exit 1
	cp -v a.out ${DESTDIR}/lib/ || exit 1
	cp -v a.out ${DESTDIR}/${PREFIX}/bin/ || exit 1
	cp -v a.out ${DESTDIR}/${PREFIX}/lib/ || exit 1
	cp -v a.out ${DESTDIR}/${PREFIX}/libexec/ || exit 1
	cp -v a.out ${DESTDIR}/${PREFIX}/sbin/ || exit 1
else
	echo "请运行 ./compile.sh"
	exit 1
fi
