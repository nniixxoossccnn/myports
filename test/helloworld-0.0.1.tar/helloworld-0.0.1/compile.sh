#!/bin/sh

# 编译测试用例
gcc helloworld.c || exit 1
